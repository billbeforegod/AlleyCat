ASETGAMES PRESENTS: ALLEY CAT 2
RELEASE DATE: 25 DECEMBER 2006
AUTHOR OF THIS SEQUEL/REMAKE: The Thinker
DEDICATED TO: BILL WILLIAMS who released Alley Cat for pc in 1984.
IF YOU WANT TO CONTACT ME PLS WRITE TO TheThinker82@gmail.com

I played Alley Cat for the first time in 1988 and I think it's the best old game you can play on a modern pc if you love video games from the past,
'Cause Alley Cat is very dynamic,very funny and never boring.
I remaked this game 'cause no one else did it, for the love of programming and of course to make my special tribute to Bill Williams the original maker of Alley Cat.
Also I spent 3 months ripping all graphics files and sprites from the original game to help the remakers around the world to create more Alley Cat remakes.

IF YOU WANT TO CONTACT ME PLS WRITE TO: TheThinker82@gmail.com

asetgames.altervista.org
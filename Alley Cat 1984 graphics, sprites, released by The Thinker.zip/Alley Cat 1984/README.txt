This archive contains all graphic files and sprites of Alley Cat ripped by The Thinker after 3 months of hard work.
Most of them were used for my Alley Cat 2 game that I made as tribute to Bill Williams the maker of Alley Cat.
If you need these files, use them freely to make your alley cat remake.

The Thinker

If you want to contact me pls write to TheThinker82@gmail.com

asetgames.altervista.org
